import pandas as pd

from utils import read_csv_fast, save_csv_pkl

pd.options.mode.chained_assignment = None

NEURO_W_PSYCH_JOURNALS = {
  'cognition', 'memory_amp_cognition', 'cognitive_science',
  'journal_of_memory_and_language', 'human_factors',
  'journal_of_communication_disorders',
  'journal_of_contextual_behavioral_science',
  'journal_of_the_experimental_analysis_of_behavior',
  'international_journal_of_behavioral_development',
  'learning_and_motivation',
  'cognitive_processing', 'cognitive_psychology',
  'learning_amp_behavior',
  'topics_in_cognitive_science',
  'nature_human_behaviour',
  'the_quarterly_journal_of_experimental_psychology',
  'journal_of_behavioral_and_cognitive_therapy',
  'quarterly_journal_of_experimental_psychology',
  'asian_journal_of_sport_and_exercise_psychology',
  'journal_of_research_on_adolescence',
  'evolutionary_psychology',
  'adaptive_behavior',
  'british_journal_of_developmental_psychology',
  'journal_of_behavioral_and_cognitive_therapy',
  'human_factors_the_journal_of_the_human_factors_and_ergonomics_society',
  'child_development_research',
  'cognitive_systems_research',
  'sleep_medicine_clinics',
  'journal_of_fluency_disorders',
  'chronic_stress',
  'developmental_science'}

NEURO_JOURNALS = \
{'psychophysiology',
  'current_developmental_disorders_reports',
  "american_journal_of_alzheimer's_disease_amp_other_dementiasr",
  'mind,_brain,_and_education',
  "american_journal_of_alzheimer's_disease_amp_other_dementias®",
  'adaptive_human_behavior_and_physiology',
  'applied_psychophysiology_and_biofeedback',
  'brain_research._cognitive_brain_research',
  'archives_of_clinical_neuropsychology__the_official_journal_of_'
  'the_national_academy_of_neuropsychologists',
  'computational_brain_amp_behavior', 'neurobiology_of_learning_and_memory',
  'cortex;'
  '_a_journal_devoted_to_the_study_of_the_nervous_system_and_behavior',
  'trends_in_cognitive_sciences',
  'biologically_inspired_cognitive_architectures',
  'brain_and_cognition', 'brain_and_language', 'developmental_psychobiology',
  'physiology_amp_behavior',
  'cognitive_research_principles_and_implications', 'cortex',
  'journal_of_neurolinguistics', 'neuropsychologia',
  'evolutionary_psychology__an_international_journal_of_evolutionary_'
  'approaches_to_psychology_and_behavior',
}


def make_pruned_df(fp):
  assert 'combined' in fp
df = read_csv_fast(fp, verbose=0)

df = df[df['journal'] != 'journal_of_fluorescence']  # lens.org error entry?
df = df[(df['is_neuro'] != True) |
          (df['journal'].isin(NEURO_W_PSYCH_JOURNALS))]

df = df[df['year'] >= 2004]

print(f'Number of papers in year from 2004-2024: {len(df):,}')

len_2004 = len(df)
df = df[df['has_results'] == True]
print(f'\tNumber of papers with results: {len(df):,} '
      f'({len(df) / len_2004:.1%})')
len_pre = len(df)

df = df[df['jrl_cnt'] >= 5]
num_dropped = len_pre - len(df)
print(f'\tNumber of papers with >= 5 papers in journal (true has_results): '
      f'{len(df):,} ({num_dropped=})')

# Drop papers with bad journals, years, no SNIP, no school
#   but with a Results section
if 'all_aff' not in fp:
  df_emp = df[(df['SNIP'].notna()) & (df['school'].notna())]
fp_out = fp.replace('combined', 'combined_all_empirical')
print(f'Number of papers with Results and SNIP and school: '
      f'{len(df_emp):,}')
save_csv_pkl(df_emp, fp_out, check_dup=False, verbose=0)

df['has_ps'] = df['num_ps_any'] > 0
pre_len = len(df)
df = df[df['has_ps'] == True]
print(f'\tNumber of papers with p-values: {len(df):,} '
      f'({len(df) / pre_len:.1%})')
if df['sig'].max() == 1:  # i.e., a _by_pval dataframe
  ps_per_paper = df.groupby('doi_str')['sig'].sum()
df['num_sig_in_paper'] = df['doi_str'].map(ps_per_paper)
df['has_signif_ps'] = df['num_sig_in_paper'] > 1
df = df[df['has_signif_ps'] == True]
df.drop(columns=['has_signif_ps'], inplace=True)
print(f'\tNumber of ps after dropping papers with under 2 sig: '
      f'{len(df):,}')
else:
  print('-*-')
fp_out = fp.replace('combined', 'combined_w_no_sig')
all_insig = ((df['num_ps_any'] > 0) & (df['sig'] == 0)).sum()

print(f'\tNumber of papers with only insignificant results: {all_insig:}')
all_insig = ((df['num_ps_any'] > 1) & (df['sig'] == 0)).sum()
print(f'\tNumber of papers with only insignificant results (2+ p-values): {all_insig:}')
save_csv_pkl(df, fp_out, check_dup=False, verbose=0)
df['has_signif_ps'] = df['sig'] > 0
df = df[df['has_signif_ps'] == True]
print(f'\tNumber of papers with significant p-values: {len(df):,}')
df['has_signif_ps'] = df['sig'] > 1
df = df[df['has_signif_ps'] == True]
df.drop(columns=['has_signif_ps'], inplace=True)
print(f'\tNumber of papers with 2+ signif. p-values: {len(df):,}')
n_nan_snip = df['SNIP'].isna().sum()
print(f'\tNumber of papers with NaN SNIP: {n_nan_snip:,}')
if 'all_aff' in fp:
  n_nan_affil = df['Random_school'].isna().sum()
print(f'\tNumber of papers with NaN affiliation: {n_nan_affil:,}')
df_pruned = df[df['SNIP'].notna() & df['Random_school'].notna()]
aff_types = ['Random', 'TargetMax', 'TargetMin', 'TargetMed',
             'YearMax', 'YearMin', 'YearMed',
             'Mean', 'Mode']
for aff_type in aff_types:
  assert df_pruned[f'{aff_type}_target_score'].notna().all()
assert df_pruned[f'{aff_type}_year_score'].notna().all()
else:
  n_nan_affil = df['school'].isna().sum()
print(f'\tNumber of papers with NaN affiliation: {n_nan_affil:,}')
df_pruned = df[df['SNIP'].notna() & df['school'].notna()]
print(f'Final dataset size if dropping SNIP or no-university: '
      f'{len(df_pruned):,}')
fp_out = fp.replace('combined', 'combined_pruned')
save_csv_pkl(df_pruned, fp_out, check_dup=False, verbose=0)
print('-*-')

fp_out = fp.replace('combined', 'combined_semi_pruned')
save_csv_pkl(df, fp_out, check_dup=False, verbose=0)
print('-*-')


if __name__ == '__main__':
  # One row = one paper. Used for most of the multilevel regressions)
  make_pruned_df(r'..\dataframes\df_combined_Jan21.csv')

# One row = one reported p-value (used for the language analysis)
make_pruned_df(r'..\dataframes\df_by_pval_combined_Jan21.csv')

# This one includes alternative university assignments (e.g., max or mean)
make_pruned_df(r'..\dataframes\df_combined_all_aff_Jan21.csv')



from collections import defaultdict

import numpy as np
import pandas as pd

from utils import read_csv_fast, save_csv_pkl

# Suppress SettingWithCopyWarning
pd.options.mode.chained_assignment = None


def interpolate_journal(df, key='p_fragile'):
  df_j = df.groupby(['journal_clean', 'year'])[key].mean()
p_na = pd.isna(df[key])
p_na = p_na & df['journal_clean'].notna() & df['year'].notna()
df[f'{key}_j'] = df[key]
df.loc[p_na, f'{key}_j'] = df[p_na].apply(
  lambda row: df_j[row['journal_clean'], row['year']], axis=1)
return df


def add_jrl_cnt(df, limit=5):
  df_j = df[df['has_results'] == True].groupby(
    ['journal_clean', 'year'])['doi_str'].count()
df['jrl_cnt'] = df.apply(
  lambda row: df_j[row['journal_clean'], row['year']] if
  (row['journal_clean'], row['year']) in df_j else np.nan, axis=1)
df['has_results_j'] = df['has_results']
df.loc[df['jrl_cnt'] < limit, 'has_results_j'] = False


def get_non_ps_df(all_aff=False):
  fp_aff = fr'../dataframes/df_affiliation_Aug24.csv'
df_aff = read_csv_fast(fp_aff)

# made many affiliation columns, lets just pick the ones we care about

if all_aff:
  aff_types = ['Random', 'TargetMax', 'TargetMin', 'TargetMed',
               'YearMax', 'YearMin', 'YearMed',
               'Mean', 'Mode']
col_specific = ['school', 'country',
                'target_rank', 'target_score',
                'year_rank', 'year_score', ]
cols = []
for aff_type in aff_types:
  for col in col_specific:
  if aff_type == 'Mean' and col in ['school', 'country']:
  continue
cols.append(f'{aff_type}_{col}')
cols += ['doi_str', 'num_affil']

df_aff = df_aff[cols]
else:
  cols = ['Mode_school', 'Mode_country',
          'Mode_year_rank', 'Mode_target_rank',
          'Mode_year_score', 'Mode_target_score',
          'doi_str', 'num_affil']
df_aff = df_aff[cols]
mapper = {col: col.replace('Mode_', '') for col in cols}
df_aff.rename(columns=mapper, inplace=True)

df_aut = read_csv_fast(f'../dataframes/df_author_ages_Aug24.csv')

cols = list(df_aut.columns.difference(df_aff.columns)) + ['doi_str']
df = df_aff.merge(df_aut[cols], on='doi_str', how='outer')

df_subjects = read_csv_fast(f'../dataframes/df_subjects_Aug24.csv')
cols = list(df_subjects.columns.difference(df.columns)) + ['doi_str']
df = df.merge(df_subjects[cols], on='doi_str', how='outer')

df_SNIP = read_csv_fast(f'../dataframes/df_SNIP_Aug24.csv')
cols = list(df_SNIP.columns.difference(df.columns)) + ['doi_str']
df = df.merge(df_SNIP[cols], on='doi_str', how='outer')

fp_text = fr'../dataframes/df_text_Aug24.csv'
df_text = read_csv_fast(fp_text, easy_override=False)
df_text = df_text[['doi_str', 'baye_paper', 'freq_paper', 'ML_paper']]
df = df.merge(df_text, on='doi_str', how='outer')

if not all_aff:
  mthd2school2M = {'baye': {}, 'freq': {}, 'ML': {}}
for method in ['baye', 'freq', 'ML']:
  for school in df['school'].unique():
  df_school = df[df['school'] == school]
mthd2school2M[method][school] = (
  df_school[f'{method}_paper'].mean())
df[f'school_M_{method}'] = df['school'].map(mthd2school2M[method])

fp_has_results = f'../dataframes/df_has_results_Aug24.csv'
df_has_results = read_csv_fast(fp_has_results)
df = df.merge(df_has_results[['doi_str', 'has_results']],
              on='doi_str', how='outer')

fp_cites = r'../dataframes/df_cites_Aug24.csv'
df_cites = read_csv_fast(fp_cites)
df = df.merge(df_cites, on='doi_str', how='outer')

fp_journal_clean = r'../dataframes/df_lens_Aug24.csv'
df_journal_clean = read_csv_fast(fp_journal_clean)
df = df.merge(df_journal_clean[['doi_str', 'journal_clean']],
              on='doi_str', how='outer')
print('Made most of the non-p component of the final dataframe')
print('-*' * 10 + '-')
return df


def make_combined_df(all_aff=False):
  fp_p = r'../dataframes/df_p_process_Jan21.csv'
df_p = read_csv_fast(fp_p)
df_non_p = get_non_ps_df(all_aff=all_aff)

print(f'p/z-value df: {len(df_p)=}')

cols = list(df_p.columns.difference(df_non_p.columns)) + ['doi_str']
df = df_non_p.merge(df_p[cols], on='doi_str', how='outer')
df['num_ps'] = df['num_ps'].fillna(0)

df_lens = read_csv_fast(r'..\dataframes\df_lens_Aug24.csv', verbose=0)
if 'journal_clean' in df.columns:
  df.drop(columns=['journal_clean'], inplace=True)
df = df.merge(df_lens[['doi_str', 'journal_clean']], on='doi_str',
              how='left')

interpolate_journal(df, key='p_fragile')
add_jrl_cnt(df)

if 'journal_clean_x' in df.columns:
  df.drop(columns=['journal_clean_x', 'journal_clean_y'], inplace=True)

# these are redundant or not meaningful
df.drop(columns=['index', 'lens_cites', 'cnt',
                 'insig_exact_implied', 'insig_less_implied',
                 'n001_exact_implied', 'n001_less_implied',
                 'n005_h_exact_implied', 'n005_h_less_implied',
                 'n005_l_exact_implied', 'n005_l_less_implied',
                 'n05_exact_implied', 'n05_less_implied',
                 'n_exact05_implied', 'num_ps_exact_implied',
                 'num_ps_less_implied', 'sig_exact_implied',
                 'sig_less_implied',
],
inplace=True)

if not all_aff:
  df_school = df[df['num_ps'] > 0].groupby('school')['country'].first()
country2school_cnt = defaultdict(int)
for school, country in df_school.items():
  country2school_cnt[country] += 1
df['country_school_count'] = df['country'].map(country2school_cnt)

# needed for the df_by_pval, which can't calculate jrnl cnt or school count
save_csv_pkl(df[['doi_str', 'jrl_cnt', 'country_school_count']],
             r'../dataframes/df_journal_school_count_Jan21.csv')

aff_all_str = '_all_aff' if all_aff else ''
fp_out = f'../dataframes/df_combined{aff_all_str}_Jan21.csv'
print(f'{fp_out=}')

save_csv_pkl(df, fp_out)
print('Made combined dataframe')


def make_combined_by_pval(all_aff=False):
  df_non_p = get_non_ps_df(all_aff=all_aff)
fp_p = r'../dataframes/df_p_processed_by_p_Jan21.csv'
df_by_p = read_csv_fast(fp_p)
df_p_by_p_cols = set(df_by_p.columns)
df_cols = set(df_non_p.columns)
overlap_cols = df_p_by_p_cols.intersection(df_cols)
cols = list(df_p_by_p_cols - overlap_cols) + ['doi_str']
df_by_p = df_by_p[cols].merge(df_non_p, on='doi_str')
df_other = read_csv_fast(r'../dataframes/df_journal_school_count_Jan21.csv')
df_by_p = df_by_p.merge(df_other, on='doi_str')

aff_all_str = '_all_aff' if all_aff else ''
fp_out = fr'../dataframes/df_by_pval_combined{aff_all_str}_Jan21.csv'
if 'journal_clean_x' in df_by_p.columns:
  df_by_p.drop(columns=['journal_clean_x', 'journal_clean_y'])
save_csv_pkl(df_by_p, fp_out, check_dup=False)
print('Made combined-by-p-value dataframe')
print('-*' * 10 + '-')


if __name__ == '__main__':
  make_combined_df()
make_combined_by_pval()
make_combined_df(all_aff=True)


from collections import defaultdict
from datetime import datetime

import numpy as np
import pandas as pd
from tqdm import tqdm

from utils import read_csv_fast, pickle_wrap, save_csv_pkl

smol = 1e-6

pd.options.mode.chained_assignment = None


def categorize_paper_pvals(df_by_p, thresh=.999999, p_key=''):
  doi2cond = {}
doi2lower_cutoff = {}
if p_key is None:
  p_key = 'p_val'
else:
  p_key = f'p_val{p_key}'

df_p_by_p_ = df_by_p[['doi_str', 'sign', p_key, ]]
for doi_str, df_doi in tqdm(df_p_by_p_.groupby('doi_str'),
                            desc='categorizing papers'):
  doi2cond[doi_str] = 'ERROR'

is_sig = ((df_doi[p_key] < .05 + smol) &
            (df_doi['sign'].isin(['<', '='])))
df_sig = df_doi[is_sig]
if not len(df_sig):
  doi2cond[doi_str] = 'no_sig'
doi2lower_cutoff[doi_str] = pd.NA
continue

# Ignore "p = .05"
equal05 = ((df_sig[p_key] < .05 + smol) &
             (df_sig[p_key] > .05 - smol) &
             (df_sig['sign'] == '='))

df_sig = df_sig[~equal05]

if not len(df_sig):
  doi2cond[doi_str] = 'all_equal0.05'
doi2lower_cutoff[doi_str] = .05
continue

prop_less_than = (df_sig['sign'] == '<').mean()
if prop_less_than > thresh:
  for cutoff_ in [.000, .0001, .0005, .001, .005, .01, .05,
                  '_custom']:
  # .000 is strange, but some papers report "p < .000"
  if cutoff_ == '_custom':
  # e.g., if an author, always reports p < .0125 because
  #   they like having the same less-than p-value everywhere
  #   and use a p < .05 threshold bonferroni corrected 4x
  cutoff = df_sig[p_key].mode().iloc[0]
else:
  # e.g., always reports p < .05 or always p < .01
  cutoff = cutoff_

is_less_cut = ((df_sig[p_key] < cutoff + smol) &
                 (df_sig[p_key] > cutoff - smol) &
                 (df_sig['sign'] == '<'))
prop_less_cut = is_less_cut.mean()
if prop_less_cut > thresh:
  doi2cond[doi_str] = f'all_less{cutoff_}'
doi2lower_cutoff[doi_str] = cutoff
break
else:
  lowest_p = df_sig[p_key].min()
for cutoff_ in [.000, .0001, .0005, .001, .005, .01]:
  # e.g., if an author, always reports "<" but in different
  #   ways, like p < .05 and p < .001.
  # cutoff_ = .001 means that the lowest is p < .001 or lower
  if cutoff_ - smol < lowest_p < cutoff_ + smol:
  doi2cond[doi_str] = f'all_less_mixed{cutoff_}'
doi2lower_cutoff[doi_str] = cutoff_
break
else:
  doi2cond[doi_str] = f'all_less_mixed_custom'
doi2lower_cutoff[doi_str] = lowest_p
continue
continue

is_equal = df_sig['sign'] == '='
prop_equal = is_equal.mean()
if prop_equal > thresh:
  doi2cond[doi_str] = 'all_equal'
# Not actually a cutoff, but it's still useful to note lowest p = x
doi2lower_cutoff[doi_str] = df_sig[p_key].min()
continue

for cutoff_ in [.000, .0001, .0005, .001, .005, .01, '_custom']:
  if cutoff_ == '_custom':
  cutoff = (
    df_sig[df_sig['sign'] == '<'][p_key].mode().iloc[0])
else:
  cutoff = cutoff_
is_less_cut = ((df_sig[p_key] < cutoff + smol) &
                 (df_sig[p_key] > cutoff - smol) &
                 (df_sig['sign'] == '<'))
is_equal_cut = ((df_sig['sign'] == '=') &
                  (df_sig[p_key] > cutoff - smol))
is_equal_less_cut = is_equal_cut | is_less_cut
prop_equal_less_cut = is_equal_less_cut.mean()
if prop_equal_less_cut > thresh:
  doi2cond[doi_str] = f'equal_less{cutoff_}'
doi2lower_cutoff[doi_str] = cutoff
break
else:
  doi2cond[doi_str] = 'eclectic'
doi2lower_cutoff[doi_str] = pd.NA

cond2cnt = defaultdict(lambda: 0)
for cond in doi2cond.values():
  cond2cnt[cond] += 1

return df_by_p, doi2cond, doi2lower_cutoff


def semi_prep(key=None):
  fp_p_by_p = fr'../dataframes/df_by_pval_Jan21.csv'
df_by_p = read_csv_fast(fp_p_by_p, check_dup=False)
sign_mapper = {'=': '=', '<': '<', '>': '>',
  '≤': '<', '≥': '>'}
df_by_p['sign'] = df_by_p['sign'].map(sign_mapper)

df_by_p, doi2cond, doi2lower_cutoff = (
  categorize_paper_pvals(df_by_p, p_key=key))
return df_by_p, doi2cond, doi2lower_cutoff


def parse_p(stat, sign):
  out = {'sig_exact': 0, 'n05_exact': 0, 'n005_h_exact': 0, 'n005_l_exact': 0,
    'n001_exact': 0, 'num_ps_exact': 0,
    'sig_less': 0, 'n05_less': 0, 'n005_h_less': 0, 'n005_l_less': 0,
    'n001_less': 0, 'num_ps_less': 0,
    
    'insig_exact': 0, 'insig_less': 0, 'insig_over': 0,
    'num_ps_any': 0, 'n_exact05': 0
  }

if not pd.isna(stat):
  if sign == '=':
  if 0.05 - smol < stat < .05 + smol:  # Note: p = .05 is excluded
  out['n_exact05'] = 1
elif stat < .05 + smol:
  out['num_ps_exact'] = 1
out['sig_exact'] = 1
if stat > .01 - smol:
  out['n05_exact'] = 1
elif stat > .005 - smol:
  out['n005_h_exact'] = 1
elif stat > .001 - smol:
  out['n005_l_exact'] = 1
else:
  out['n001_exact'] = 1
else:
  out['num_ps_exact'] = 1
out['insig_exact'] = 1
elif sign == '<':
  out['num_ps_less'] = 1
if stat < .05 + smol:
  out['sig_less'] = 1
if stat > .01 + smol:
  out['n05_less'] = 1
elif stat > .005 + smol:
  out['n005_h_less'] = 1
elif stat > .001 + smol:
  out['n005_l_less'] = 1
else:
  # Note: p < .001 is considered both n001_less and n001_exact
  out['n001_less'] = 1
out['n001_exact'] = 1
else:
  out['insig_less'] = 1
elif sign == '>':
  out['insig_over'] = 1
else:
  raise ValueError

out['sig'] = out['sig_exact'] or out['sig_less']
out['n05'] = out['n05_exact'] or out['n05_less']
out['n005_h'] = out['n005_h_exact'] or out['n005_h_less']
out['n005_l'] = out['n005_l_exact'] or out['n005_l_less']
out['n01'] = out['n005_h'] or out['n005_l']
out['n001'] = out['n001_exact'] or out['n001_less']
out['n01_001'] = out['n01'] or out['n001']
out['num_ps'] = out['num_ps_exact'] or out['num_ps_less']
out['num_ps_any'] = out['num_ps'] or out['insig_over'] or out['n_exact05']
out['insig'] = out['insig_exact'] or out['insig_less'] or out['insig_over']

# Papers that report exactly still usually have p < .001
out['sig_exact'] = out['sig_exact'] or out['n001_less']
out['num_ps_exact'] = out['num_ps_exact'] or out['n001_less']

return out


def make_p_processed_dfs():
  # fp_semi_prep = r'../cache/semi_prep_p.pkl'
  fp_semi_prep = r'../cache/semi_prep_p_Jan21.pkl'
df_by_p, doi2cond, doi2lower_cutoff = pickle_wrap(
  semi_prep, fp_semi_prep, RAM_cache=False, easy_override=False,
  dt_max=datetime(2024, 8, 26, 10, 20, 0, 0))

p_cats = df_by_p[['p_val', 'sign']].apply(
  lambda x: parse_p(x['p_val'], x['sign']), axis=1)
p_cats = pd.DataFrame(p_cats.tolist())

p_implied_cats = df_by_p['p_implied'].apply(lambda x: parse_p(x, '='))
p_implied_cats = pd.DataFrame(p_implied_cats.tolist())
p_implied_cats['has'] = (~pd.isna(df_by_p['p_implied'])).astype(int)
p_implied_cats = p_implied_cats.add_suffix('_implied')

df_by_p = pd.concat([df_by_p, p_cats, p_implied_cats, ], axis=1)

df_by_p['cnt'] = 1
df_by_p['cond'] = df_by_p['doi_str'].map(doi2cond)
# df_test = df_by_p[df_by_p['cond'] == 'all_less0.05']
# print(df_test['p_fragile_implied'])
# quit()

df_by_p['sig_has_implied'] = df_by_p[['sig', 'has_implied']].all(axis=1).astype(int)

cols = (list(p_cats.columns) + list(p_implied_cats.columns) +
          ['cnt', 'sig_has_implied'])

df = df_by_p.groupby('doi_str')[cols].sum()
for end in ['_val', '_implied', ]:
  df[f'lowest_p{end}'] = (
    df_by_p.groupby('doi_str')[f'p{end}'].min())

df_t = df_by_p[df_by_p['stat_type'] == 't']
df_t['t_N'] = df_t['df1'] + 1
df_t['d'] = df_t['stat'].abs() / np.sqrt(df_t['t_N'])
df[['t_N', 'd']] = df_t.groupby('doi_str')[['t_N', 'd']].median()

df_t_sig = df_by_p[df_by_p['sig'] == 1]
df_t_sig = df_t_sig[df_t_sig['stat_type'] == 't']
df_t_sig['t_N_sig'] = df_t_sig['df1'] + 1
df_t_sig['d_sig'] = (df_t_sig['stat'].abs() /
                       np.sqrt(df_t_sig['t_N_sig']))

df[['t_N_sig', 'd_sig']] = df_t_sig.groupby('doi_str')[[
  't_N_sig', 'd_sig']].median()

df.reset_index(inplace=True)
df['cond'] = df['doi_str'].map(doi2cond)

# not used for manuscript
df['p_cutoff'] = df['doi_str'].map(doi2lower_cutoff)

df['prop_implied'] = df['num_ps_implied'] / df['num_ps']

for end in ['', '_implied', ]:
  df[f'p_fragile{end}'] = df[f'n05{end}'] / df[f'sig{end}']

# counts reported/interpreted one-tailed significance in the denominator
df[f'p_fragile_implied_rel_sig'] = (df[f'n05_implied'] /
                                      (df['sig_has_implied']))

df[f'p_fragile_w_exact05'] = ((df[f'n05'] + df['n_exact05']) /
                                (df[f'sig'] + df['n_exact05']))
df['p_fragile_orig'] = df['p_fragile']

# cnt_na = df['p_fragile'].isna().sum()
# print(F'{cnt_na=}')
# print(f'{len(df)=}')
# df_ = df[df['cond'] == 'all_less0.05']
# print(df_[['p_fragile', 'p_fragile_implied']])

df.loc[df['cond'] == 'all_less0.05', 'p_fragile'] = (
  df)[df['cond'] == 'all_less0.05']['p_fragile_implied']
# cnt_na = df['p_fragile'].isna().sum()
# print(F'{cnt_na=}')
# df_ = df[df['cond'] == 'all_less0.05']
# print(df_[['p_fragile', 'p_fragile_implied']])
# M = np.nanmean(df_['p_fragile'])
# print(f'{M=}')
# M = np.nanmean(df_['p_fragile_implied'])
# print(f'{M=}')
# quit()

df.loc[df['cond'] == 'all_less0.05', 'p_fragile'] = (
  df.loc[df['cond'] == 'all_less0.05', 'p_fragile'].fillna(0.509))

# cnt_na = df['p_fragile'].isna().sum()
# print(F'{cnt_na=}')
# quit()


fp_out_by_p = fr'../dataframes/df_p_processed_by_p_Jan21.csv'
save_csv_pkl(df_by_p, fp_out_by_p, check_dup=False)

fp_out = r'../dataframes/df_p_process_Jan21.csv'
save_csv_pkl(df, fp_out, check_dup=False)
return df


if __name__ == '__main__':
  make_p_processed_dfs()




import pickle

import numpy as np
import pandas as pd

from utils import read_csv_fast, save_csv_pkl

pd.options.mode.chained_assignment = None


def make_subject_df():
  def make_subject_tuple(l):
  if l is None:  # Scopus API generates nothing for ~1.2% of cases
  return tuple([pd.NA] * 9)
out = []
for area in targets:
  out.append(area in l)
is_psych = any(out)

for l_area in l:
  if 'neuro' in l_area.lower():
  is_neuro = True
break
else:
  is_neuro = False
return (is_psych, is_neuro, *out)

targets = ['Developmental and Educational Psychology',
           'Psychology (all)', 'Social Psychology',
           'Applied Psychology', 'Clinical Psychology',
           'Experimental and Cognitive Psychology',
           'Psychology (miscellaneous)', ]

with open(rf'../cache/journal_to_SCOPUS_subject_Jan21.pkl', 'rb') as f:
  journal_to_ASJC_ = pickle.load(f)

journal_to_ASJC = {}
for journal, l in journal_to_ASJC_.items():
  journal_to_ASJC[journal] = make_subject_tuple(l)

df = read_csv_fast(rf'../dataframes/df_has_results_Aug24.csv')

# Rename Psychology ('all') to 'General Psychology' for consistency with
#    my initial submission and the older CrossRef naming
new_cols = ['is_psych', 'is_neuro',
            'Developmental_and_Educational_Psychology',
            'General_Psychology', 'Social_Psychology',
            'Applied_Psychology', 'Clinical_Psychology',
            'Experimental_and_Cognitive_Psychology',
            'Psychology_Miscellaneous']

# SettingWithCopyWarning is annoying. Not even sure what triggers it here
pd.options.mode.chained_assignment = None
df[new_cols] = df['journal'].map(journal_to_ASJC).apply(pd.Series)
df = df[['doi_str'] + new_cols]

fp_out = rf'../dataframes/df_subjects_Jan21.csv'
save_csv_pkl(df, fp_out)
print('Saved df_subjects')


def make_SNIP_df():
  def get_SNIP(journal, year):
  try:
  return journal_to_SNIP[journal][year]
except KeyError:
  try:
  d_journal = journal_to_SNIP[journal]
while year < 2024:
  year += 1
if year in d_journal:
  return d_journal[year]
return np.nan
except KeyError:
  return np.nan
except TypeError:
  return np.nan

def check_if_exact_SNIP(journal, year):
  if journal in journal_to_SNIP:
  if journal_to_SNIP[journal] is None:
  return np.nan
if year in journal_to_SNIP[journal]:
  return 1
else:
  return 0
else:
  return np.nan

with open(rf'../cache/journal_to_SNIP_Jan21.pkl', 'rb') as f:
  journal_to_SNIP = pickle.load(f)
for journal, d in journal_to_SNIP.items():
  if d is None:
  journal_to_SNIP[journal] = None
continue

journal_to_SNIP[journal] = {int(year): v for year, v in d.items()}

df = read_csv_fast(rf'../dataframes/df_has_results_Aug24.csv')
df = df[df['has_results'] == True]
covered_journals = set(journal_to_SNIP.keys())
df = df[df['journal'].isin(covered_journals)]

df['year'] = df['year'].astype(int)
df['exact_SNIP'] = df[['journal', 'year']].apply(
  lambda row: check_if_exact_SNIP(row['journal'], row['year']), axis=1)
print(df['exact_SNIP'].value_counts(dropna=True, normalize=True))

df['SNIP'] = df[['journal', 'year']].apply(
  lambda row: get_SNIP(row['journal'], row['year']), axis=1)
df['SNIP'] = df['SNIP'].astype(float)

num_nan = df['SNIP'].isna().sum()
print(f'Number with missing SNIP: {num_nan}')
fp_out = rf'../dataframes/df_SNIP_Jan21.csv'
save_csv_pkl(df[['doi_str', 'SNIP']], fp_out)
print('Saved df_jif')
# Sorry but the _Aug24.csv cannot be produced again. I foolishly deleted my
#   "journal_to_SCOPUS_subject.pkl" from when I originally made it in august
#   now, when make_journal_d_scopus.py is run, the API will return slightly
#   different things (particularly for 2024 papers). The difference is very small
#   and I believe stems from more paper being added to Scopus
# Just use df_SNIP_Aug24.csv if you want to reproduce the paper

if __name__ == '__main__':
  make_subject_df()
make_SNIP_df()




import pickle
from pathlib import Path

import pandas as pd
import pybliometrics
from crossref.restful import Works
from pybliometrics.scopus import SerialTitle
from pybliometrics.scopus.exception import Scopus404Error, Scopus401Error
from tqdm import tqdm

from utils import read_csv_fast

pd.options.mode.chained_assignment = None

if __name__ == '__main__':
  pybliometrics.scopus.init()

works = Works()
df = read_csv_fast(rf'../dataframes/df_has_results_Aug24.csv')

df = df[df['has_results'] == True]

df.sort_values('year', inplace=True, ascending=False)
df_per_journal = df.groupby('journal').first()  # also includes some books
df_per_journal.reset_index(inplace=True)

d_subject = {}
d_yr2SNIP = {}
bad_journals = []
for row in tqdm(df_per_journal.itertuples(),
                total=df_per_journal.shape[0],
                desc='Making journal to ASJC'):
  ISSN = row.ISSNs
if pd.isna(ISSN):
  print(f'Missing ISSN key: {row.journal}')
bad_journals.append(row.journal)
d_subject[row.journal] = None
continue
backup_ISSN = row.backup_ISSN
try:
  res = SerialTitle(ISSN, years='2004-2024', view='ENHANCED')
except Scopus404Error as e:
  if pd.isna(backup_ISSN):
  print(f'Bad ISSN: {row.journal}: {e}')
bad_journals.append(row.journal)
d_subject[row.journal] = None
continue
else:
  print('Trying backup ISSN after 404 error')
try:
  res = SerialTitle(backup_ISSN, years='2004-2024',
                    view='ENHANCED')
print('\tSuccesfully used backup!')
except Scopus404Error as e:
  print(f'Bad ISSNs: {row.journal}: {e}')
bad_journals.append(row.journal)
d_subject[row.journal] = None
continue
except Scopus401Error as e:
  # 10,000 or so lines in I cba to turn below into a function...
  if pd.isna(backup_ISSN):
  bad_journals.append(row.journal)
d_subject[row.journal] = None
continue
else:
  print('Trying backup ISSN after 401 error')
try:
  res = SerialTitle(backup_ISSN, years='2004-2024',
                    view='ENHANCED')
print('\tSuccesfully used backup!')
except Scopus404Error as e:
  print(f'???: {row.journal}: {e}')
bad_journals.append(row.journal)
d_subject[row.journal] = None
continue

d_yr2SNIP[row.journal] = {}
try:
  SNIP_info = vars(res)['_entry']['SNIPList']['SNIP']
for entry in SNIP_info:
  year = entry['@year']
SNIP = entry['$']
d_yr2SNIP[row.journal][int(year)] = SNIP
except KeyError as e:
  print(f'No SNIP: {row.journal}')
d_yr2SNIP[row.journal] = None
bad_journals.append(row.journal)

try:
  subject_areas = res.subject_area
except KeyError as e:
  print(f'No subject areas: {row.journal}')
bad_journals.append(row.journal)
d_subject[row.journal] = None
continue
subject_areas = [sa[0] for sa in subject_areas]
d_subject[row.journal] = subject_areas
print(f'{bad_journals=}')

df_ = df[df['journal'].isin(bad_journals)]
n_all = len(df)
n_bad = len(df_)
print(f'Bad journals: {n_bad}/{n_all} ({n_bad / n_all:.1%})')  # Only ~1.2%
fp_out = rf'../cache/journal_to_SCOPUS_subject_Jan21.pkl'

Path(fp_out).parent.mkdir(parents=True, exist_ok=True)
with open(fp_out, 'wb') as f:
  pickle.dump(d_subject, f)

fp_out = rf'../cache/journal_to_SNIP_Jan21.pkl'

with open(fp_out, 'wb') as f:
  pickle.dump(d_yr2SNIP, f)



import scipy.stats as stats

from utils import read_csv_fast

if __name__ == '__main__':
  fp = fr'../dataframes/df_combined_semi_pruned_Jan21.csv'
df = read_csv_fast(fp, easy_override=False)

df.dropna(subset=['d_sig', 't_N_sig', 'p_fragile'], inplace=True)

eff = df['d_sig']
N = df['t_N_sig']
p_frag = df['p_fragile']
print(f'{len(df)=:,}')
r_N_p, _ = stats.spearmanr(N, p_frag)
r_eff_N, _ = stats.spearmanr(eff, N)
r_eff_p, _ = stats.spearmanr(eff, p_frag)
print(f'Sample size (N) x p_fragile: {r_N_p=:.3f}')
print(f'Sample size (N) x effect size (d): {r_eff_N=:.3f}')
print(f'effect size (d) x p_fragile: {r_eff_p=:.3f}')



import pandas as pd

from plot_and_count.tally_TableS1_pval_reporting import (
  count_pval_reporting_style)
from text_analysis.build_df_word import get_is_fragile
from utils import read_csv_fast


def under_overreporting_p_fragile():
  fp = fr'../dataframes/df_by_pval_combined_semi_pruned_Aug24.csv'
df = read_csv_fast(fp, easy_override=False)

df.dropna(subset=['p_val', 'p_implied'], inplace=True)

df = df[df['sig'] == True]

df['p_is_fragile'] = df.apply(lambda x:
                                get_is_fragile(x['p_val'], x['sign']), axis=1)
df['p_is_fragile_implied'] = df['p_implied'].apply(get_fragile_implied_str)
df = df[df['cond'] != 'all_less0.05']
df['p_is_fragile_implied'] = df['p_implied'].apply(get_fragile_implied_str)

cnt = df[['p_is_fragile', 'p_is_fragile_implied']].value_counts(
  normalize=True, dropna=False)

prop_p_fragile = (cnt[(True, 'FRAGILE')] + cnt[(True, 'STRONG')] +
                    cnt[(True, 'INSIG')])
prop_p_fragile_strong = cnt[(True, 'STRONG')]
prop_not_really_fragile = prop_p_fragile_strong / prop_p_fragile
print(f'\t{prop_not_really_fragile:.1%} of p-values reported as fragile '
      f'are actually strong per p_implied')
prop_p_strong = (cnt[(False, 'FRAGILE')] + cnt[(False, 'STRONG')] +
                   cnt[(False, 'INSIG')])
prop_actually_fragile = cnt[(False, 'FRAGILE')] / prop_p_strong
print(f'\t{prop_actually_fragile:.1%} of p-values reported as strong are '
      f'actually fragile per p_implied')
print(cnt)
base_rate = .35
p_fragile_change = (prop_not_really_fragile * base_rate -
                      prop_actually_fragile * (1 - base_rate))
print(f'Bias: {p_fragile_change:.1%}')
print(' ^^ quantity used for adustment ^^')
print()

print('Ignoring p = .01...')
df = df[(df['p_val'] > .011) | (df['p_val'] < .009)]
cnt = df[['p_is_fragile', 'p_is_fragile_implied']].value_counts(
  normalize=True, dropna=False)

prop_p_fragile = (cnt[(True, 'FRAGILE')] + cnt[(True, 'STRONG')] +
                    cnt[(True, 'INSIG')])
prop_p_fragile_strong = cnt[(True, 'STRONG')]
prop_not_really_fragile = prop_p_fragile_strong / prop_p_fragile
print(f'\t{prop_not_really_fragile:.1%} of p-values reported as fragile '
      f'are actually strong per p_implied (ignoring p = .01)')
prop_actually_fragile = cnt[(False, 'FRAGILE')] / prop_p_strong
print(f'\t{prop_actually_fragile:.1%} of p-values reported as strong are '
      f'actually fragile per p_implied (ignoring p = .01)')
p_fragile_change = (prop_not_really_fragile * base_rate -
                      prop_actually_fragile * (1 - base_rate))
print(f'\tBias: {p_fragile_change:.1%} (ignoring p = .01)')
print(cnt)


def get_fragile_implied_str(p_implied):
  if pd.isna(p_implied):
  return pd.NA
elif p_implied > 0.05:
  return 'INSIG'
elif p_implied < .01:
  return 'STRONG'
else:
  return 'FRAGILE'


if __name__ == '__main__':
  count_pval_reporting_style()
under_overreporting_p_fragile()



import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np
import scipy.stats as stats
from tqdm import tqdm

from utils import read_csv_fast


def sample_from_num_ps():
  # read_csv_fast caches, so its not loaded every time this func is called
  fp = fr'../dataframes/df_combined_semi_pruned_Jan21.csv'
df = read_csv_fast(fp, easy_override=False)
return df['num_ps'].sample(20, replace=True)


def sim_80_power_implied_low(beta=2.8, nsim=10_000):
  np.random.seed(0)
p_fragiles = []

p_sig_cutoff = .05
z_sig_cutoff = stats.norm.isf(p_sig_cutoff / 2)
p_fragile_cutoff = .01
z_fragile_cutoff = stats.norm.isf(p_fragile_cutoff / 2)

fp = fr'../dataframes/df_combined_semi_pruned_Jan21.csv'
df = read_csv_fast(fp, easy_override=False)
num_ps = df['num_ps'].astype(int).sample(nsim, replace=True)
prop_sigs = []
for num_p in num_ps:
  sig_zs = []
while len(sig_zs) < 1:  # no sig
  zs = np.random.normal(beta, size=num_p)
sig_zs = zs[zs > z_sig_cutoff]
if len(sig_zs) == 0:
  prop_sigs.append(0)
# prop_sigs will be over nsim but that's fine
prop_sig = len(sig_zs) / len(zs)
prop_sigs.append(prop_sig)
p_fragile = np.mean(sig_zs < z_fragile_cutoff)
p_fragiles.append(p_fragile)

power = np.mean(prop_sigs)
print(f'Calculated power: {power:.2%}')
if beta == 2.8:
  assert 0.798 < power < 0.802
p_fragiles = np.array(p_fragiles)
M_fragile = np.mean(p_fragiles)
print(f'Mean p-fragile expected: {M_fragile:.0%}')

prop_fragile_over_50 = np.mean(p_fragiles > .5 - 1e-6)
prop_fragile_under_32 = np.mean(p_fragiles < .319)

print(f'Percentage of papers with over 50% expected: '
      f'{prop_fragile_over_50:.1%}')
print(f'Percentage of papers with under 31.9% expected: '
      f'{prop_fragile_under_32:.1%}')


def power2p05_prop(beta, nsim=1000):
  np.random.seed(0)

p_sig_cutoff = .05
z_sig_cutoff = stats.norm.isf(p_sig_cutoff / 2)
p_fragile_cutoff = .01
z_fragile_cutoff = stats.norm.isf(p_fragile_cutoff / 2)

zs = np.random.normal(beta, size=nsim)
zs_sig = zs[zs > z_sig_cutoff]
n_sig = len(zs_sig)
power = n_sig / nsim
zs_fragile = zs_sig[zs_sig < z_fragile_cutoff]
n_fragile = len(zs_fragile)
p_fragile = n_fragile / n_sig
return power, p_fragile


def plot_power2p05_prop():
  fontsize = 14

plt.rcParams.update({'font.size': fontsize,
  'font.sans-serif': 'Arial',
  'figure.figsize': (7, 4), })

betas = np.linspace(0, 10.0, 1001, endpoint=True)
powers = []
p_fragiles = []
for beta in tqdm(betas, desc='Running betas'):
  power, p_fragile = power2p05_prop(beta, nsim=100_000)
powers.append(power)
p_fragiles.append(p_fragile)

plt.plot(powers, p_fragiles, linewidth=2, color='r')
plt.xlabel('Power')
plt.gca().xaxis.set_major_formatter(mtick.StrMethodFormatter('{x:.0%}'))
plt.ylabel('Percentage of p-values\n(.01 < p < .05)')
plt.gca().yaxis.set_major_formatter(mtick.StrMethodFormatter('{x:.0%}'))
plt.yticks(fontsize=12)
plt.yticks(np.linspace(0, 1, 11), fontsize=12)
plt.xlim(0, 1.002)
plt.xticks(np.linspace(0, 1, 11), fontsize=12)
plt.ylim(0, 0.81)
plt.grid(color='lightgray', linestyle='-', linewidth=0.5, alpha=0.75)
plt.gca().spines[['right', 'top']].set_visible(False)
plt.tight_layout()
plt.show()


if __name__ == '__main__':
  plot_power2p05_prop()
sim_80_power_implied_low()

# Show that 44% power causes 50% of significant p-values to be fragile
sim_80_power_implied_low(beta=1.8)



import pandas as pd

from make_dataset.prune_to_final import NEURO_W_PSYCH_JOURNALS, NEURO_JOURNALS
from utils import read_csv_fast

pd.options.mode.chained_assignment = None

if __name__ == '__main__':
  df = read_csv_fast(r'..\dataframes\df_lens_Aug24.csv', verbose=0)
lowest_year = df['year'].min()
highest_year = df['year'].max()
print('-*- PRODUCE NUMBERS IN SUPPLEMENTAL 1 and METHODS 2.2 -*- ')
print(f'Number of Elsevier, Springer-Nature, Wiley, SAGE, Frontiers '
      f'records: {len(df):,} ({lowest_year} - {highest_year}) (SM)')
df = df[df['journal'] != 'journal_of_fluorescence']  # lens.org error entry?
pd.set_option('display.max_rows', None)
df = df[~df['journal'].isin(NEURO_JOURNALS)]
print(f'Number of records after dropping neuro: {len(df):,} (SM)')
df = df[df['year'] >= 2004]

df_ta = read_csv_fast(r'..\dataframes\df_lens_ta_Aug24.csv', verbose=0)
lowest_year = df_ta['year'].min()
highest_year = df_ta['year'].max()
print(f'\tNumber of APA and Taylor & Francis papers: {len(df_ta):,} '
      f'({lowest_year} - {highest_year})')
df_ta = df_ta[df_ta['year'] >= 2004]
print(f'\tNumber of APA/T & Fpapers in year range (2004-2024): '
      f'{len(df_ta):,} (SM)')
print()
print(f'Number of non-neuro records from 2004-2024: {len(df):,}')

df = read_csv_fast(r'..\dataframes\df_combined_Jan21.csv', verbose=0)
df = df[df['year'] >= 2004]
df = df[df['journal'] != 'journal_of_fluorescence']  # lens.org error entry?
df = df[(df['is_neuro'] != True) |
          (df['journal'].isin(NEURO_W_PSYCH_JOURNALS))]
pubs = ['Elsevier_BV', 'Springer_Science_and_Business_Media_LLC',
        'SAGE_Publications', 'Wiley', 'Frontiers_Media_SA']
df = df[df['publisher'].isin(pubs)]
print(f'\tNumber of non-neuro papers that could be retrieved: {len(df):,} '
      f'(SM)')
len_2004 = len(df)
df_results = df[df['has_results'] == True]

len_pre = len(df_results)
print(f'Number of papers with Results: '
      f'{len(df_results):,}')
df_results = df_results[df_results['jrl_cnt'] >= 5]
num_dropped = len_pre - len(df_results)
print(f'Number of papers with Results in valid journals: '
      f'{len(df_results):,}')

n_w_ps = (df_results['num_ps_any'] > 0).sum()

df_results['has_ps'] = df_results['num_ps_any'] > 0
pre_len = len(df_results)
df_results = df_results[df_results['has_ps'] == True]
print(f'Number of papers with p-values: {len(df_results):,} '
      f'({len(df_results) / pre_len:.1%})')

all_insig = ((df_results['num_ps_any'] > 0) & (df_results['sig'] == 0)).sum()
print(f'\tNumber of papers with only insignificant results: {all_insig:} '
      f'({all_insig / n_w_ps:.1%})')
all_insig = ((df_results['num_ps_any'] > 1) & (df_results['sig'] == 0)).sum()
print(f'\tNumber of papers with only insignificant results (2+ p-values): {all_insig:} '
      f'({all_insig / n_w_ps:.1%})')

df_results['has_signif_ps'] = df_results['sig'] > 1
df_results = df_results[df_results['has_signif_ps'] == True]
print(f'Number of papers with 2+ signif. p-values: {len(df_results):,} '
      f'(ie, final dataset before dropping papers without SNIP or school)')

total_num_ps = df_results['num_ps_any'].sum().astype(int)
total_num_ps_implied = df_results['num_ps_any_implied'].sum().astype(int)
percent_implied = total_num_ps_implied / total_num_ps
M_num_ps = df_results['num_ps_any'].mean()
Med_num_ps = df_results['num_ps_any'].median()
SD_num_ps = df_results['num_ps_any'].std()
print(f'Number of p-values: M = {M_num_ps:.1f} [SD = {SD_num_ps:.1f}], '
      f'median = {Med_num_ps:.1f} (total num ps = {total_num_ps:,})')
print(f'\tTotal num ps implied = {total_num_ps_implied:,} '
      f'({percent_implied:.1%})')

n_nan_snip = df_results['SNIP'].isna().sum()
n_school_semifinal = df_results['school'].nunique()
print(f'Number of papers with NaN SNIP: {n_nan_snip:,}')
n_nan_affil = df_results['school'].isna().sum()
print(f'Number of papers with NaN affiliation: {n_nan_affil:,}')
df_results = df_results[df_results['SNIP'].notna() &
                          df_results['school'].notna()]
print(f'Final dataset size w/ SNIP and school: {len(df_results):,}')
# 'num_ps_any' includes '>' and '>='
total_num_ps = df_results['num_ps_any'].sum().astype(int)
total_num_ps_implied = df_results['num_ps_any_implied'].sum().astype(int)
M_num_ps = df_results['num_ps_any'].mean()
Med_num_ps = df_results['num_ps_any'].median()
SD_num_ps = df_results['num_ps_any'].std()
print(f'\tNumber of p-values: M = {M_num_ps:.1f} [SD = {SD_num_ps:.1f}], '
      f'median = {Med_num_ps:.1f} (total num ps = {total_num_ps:,})')
df_results['journal'] = df_results['journal'].str.lower()
num_journals = len(df_results['journal'].unique())
print(f'\tNumber of journals: {num_journals:}')
num_schools = df_results['school'].nunique()
print()
print('-*- COUNT P-IMPLIED -*-')
percent_implied = total_num_ps_implied / total_num_ps
print(f'\tTotal num ps implied = {total_num_ps_implied:,} '
      f'({percent_implied:.1%})')
print()

n_schools_final = df_results['school'].nunique()

fp = r'..\dataframes\df_affiliation_all_lens_Aug24.csv'
df_aff = read_csv_fast(fp, easy_override=False, verbose=0)
n_school_any = df_aff['Mode_school'].dropna().nunique()
print('-*- PRODUCE COUNTS ON THE NUMBER OF UNIQUE UNIVERSITIES FOUND -*-')
print('Number of schools in final dataset regardless of SNIP: '
      f'{n_school_semifinal}')
# print(f'\tFinal pruned dataset with SNIP: {n_schools_final}')
print(f'\tAll downloaded papers even ones without Results: {n_school_any}')

M_num_affil = df_results['num_affil'].mean()
SD_num_affil = df_results['num_affil'].std()
med_num_affil = df_results['num_affil'].median()
print(f'\tMean number of affiliations per paper: '
      f'{M_num_affil:.2f} [SD  {SD_num_affil:.2f}], '
      f'median = {med_num_affil}')

for col in ['SNIP', 'year', 'log_cites_year_z', 'target_score']:
  assert pd.notna(df_results[col]).all(), f'{col} has NaNs'

# Sanity checkcount...
df_by_p = read_csv_fast(r'..\dataframes'
                        r'\df_by_pval_combined_pruned_Jan21.csv',
                        verbose=0)
assert total_num_ps == len(df_by_p), f'{total_num_ps=:,}, {len(df_by_p)=:,}'

df_by_p_imp = df_by_p.dropna(subset=['p_implied'])
assert len(df_by_p_imp) == total_num_ps_implied

df_empirical = read_csv_fast(
  r'..\dataframes\df_combined_all_empirical_Jan21.csv', verbose=0)
print(f'Number of paper with a Results section along with SNIP/school:'
      f' {len(df_empirical):,} (SM)')



from functools import cache
from pathlib import Path

import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
import numpy as np
import pandas as pd

from utils import read_csv_fast

pd.options.mode.chained_assignment = None


def pool_neighoring_years(df_s, grp_range=1):
  years = df_s['year'].unique()
for i in range(-grp_range, grp_range + 1):
  if i == 0: continue
df_s_cop = df_s.copy()
df_s_cop['year'] = df_s_cop['year'] + i
df_s = pd.concat([df_s, df_s_cop])
df_s = df_s[df_s.year.isin(years)]
return df_s


def plot_key(df, key='marginal', group_keys=None, ax=None,
             marker=None, shaded=True, linewidth=1):
  if ax is not None:
  plt.sca(ax)
plt.gca().spines[['right', 'top']].set_visible(False)

if not isinstance(key, tuple):
  df = df.dropna(subset=[key])

df = pool_neighoring_years(df)

group2full = {'General': 'General_Psychology',
  'Exp. & Cog.': 'Experimental_and_Cognitive_Psychology',
  'Dev. & Edu.': 'Developmental_and_Educational_Psychology',
  'Social': 'Social_Psychology',
  'Clinical': 'Clinical_Psychology',
  'Applied': 'Applied_Psychology'}

linestyles = ['solid', 'dotted', 'dashed', 'dashdot', (5, (10, 3)),
              (0, (3, 1, 1, 1, 1, 1))]

for subject in group_keys:
  df_s = df[df[group2full[subject]] == True]
yrs = []
Ms = []
SE_low = []
SE_high = []
for year, df_sy in df_s.groupby('year'):
  if isinstance(key, tuple):
  M = df_sy[key[0]].mean() - df_sy[key[1]].mean()
if 'p_fragile_only_w_implied' in key:
  SE = (df_sy[key[0]] - df_sy[key[1]]).sem()
else:
  SE = np.sqrt(df_sy[key[0]].sem() ** 2 + df_sy[key[1]].sem() ** 2)
elif key in ['d', 't_N', 'd_sig', 't_N_sig']:
  vals = df_sy[key].values
low = np.nanquantile(vals, .25)
high = np.nanquantile(vals, .75)
M = np.nanmedian(vals)
SD = (high - low) / 1.349
SE = SD / (np.sum(~np.isnan(vals)) ** 0.5)
else:
  M = df_sy[key].mean()
SE = df_sy[key].std() / (df_sy[key].count() ** 0.5)
SE_low.append(M - SE)  # *1.96)
SE_high.append(M + SE)  # *1.96)
Ms.append(M)
yrs.append(year)
plt.plot(yrs, Ms, label=subject,
         linewidth=linewidth, linestyle=linestyles.pop(0),
         marker=marker, markersize=4)
if shaded:
  plt.fill_between(yrs, SE_low, SE_high, alpha=0.2)
plt.xlim(min(df.year), max(df.year))

plt.gca().set_facecolor('whitesmoke')
plt.grid(color='lightgray', linestyle='-', linewidth=0.5, alpha=0.5)

plt.tight_layout()
plt.yticks(fontsize=11)

if key == 'p_fragile':  # 0.2998, 0.2998
  plt.title('Mean p-fragile (%)\n'
            '(.01 ≤ p < .05)',
            fontsize=12.5, pad=9)
plt.plot([min(yrs), max(yrs)], [.26, .26], '--', color='k',
         linewidth=1, zorder=-1)
plt.text(2012, 0.253, '(Expected if 80% power)',
         fontsize=11, ha='center', va='top')
plt.ylim(.21, .343)
elif key in ['p_fragile_implied', 'p_fragile_implied_rel_sig', ]:  # 0.2998, 0.2998
  plt.title('Mean implied p-fragile (%)\n(.01 < p < .05)',
            fontsize=12.5, pad=9)
plt.plot([min(yrs), max(yrs)], [.26, .26], '--', color='k',
         linewidth=1, zorder=-1)
plt.text(2011.5, 0.253, '(Expected if\n  80% power)',
         fontsize=11, ha='center', va='top')
plt.ylim(.21, .343)
elif key == 'p_bad':
  plt.title('Flagrantly unlikely to replicate\n(p-fragile ≥ 50%)',
            fontsize=12.5, pad=9)
plt.plot([min(yrs), max(yrs)], [.11, .11], '--', color='k',
         linewidth=1, zorder=-1)
plt.text(2014, 0.123, '(Expected if 80% power)',
         fontsize=11, ha='center')
plt.yticks([.1, .15, .2, .25, .3, .35])
elif key == 'p_good':
  plt.title('Optimistically replicable\n(p-fragile < 32%)',
            fontsize=12.5, pad=9)
plt.plot([min(yrs), max(yrs)], [.66, .66], '--', color='k',
         linewidth=1, zorder=-1)
plt.text(2014, 0.64, '(Expected if 80% power)',
         fontsize=11, ha='center')
elif key in ['t_N', 't_N_sig']:
  plt.title('Median sample sizes',
            fontsize=12.5, pad=9)
plt.ylim(0, 260)
elif key in ['d', 'd_sig']:
  plt.title('Median Cohen’s d',
            fontsize=12.5, pad=9)
elif isinstance(key, tuple):
  if 'implied' in key[0]:
  plt.title('Observed minus implied p-fragile\n(only papers with test statistics)',
            fontsize=12.5, pad=9)
else:
  plt.title('Observed minus implied p-fragile',
            fontsize=12.5, pad=9)
plt.ylim(-.005, .062)

plt.xticks([2004, 2008, 2012, 2016, 2020, 2024], fontsize=10.75)

if isinstance(key, tuple):
  plt.gca().yaxis.set_major_formatter(mtick.StrMethodFormatter('+{x:.0%}'))
elif 'p_fragile' in key:
  plt.gca().yaxis.set_major_formatter(mtick.StrMethodFormatter('{x:.0%}'))
if ax is None:
  plt.show()


@cache
def get_df_for_temporal_trends(bias_adjustment=.023):
  fp = fr'../dataframes/df_combined_semi_pruned_Jan21.csv'
df = read_csv_fast(fp, easy_override=False)

# Apply the adjustment after calculating the p-values, as otherwise
#   the adjustment may cause 2-p-value or 3-p-value papers to flip
df['p_bad'] = (df['p_fragile'] > .5 - 1e-6).astype(int)
df['p_good'] = (df['p_fragile'] < .319).astype(int)
df['p_fragile'] -= bias_adjustment
df['gap'] = df['p_fragile'] - df['p_fragile_implied']
M_gap = df['gap'].mean()
print(f'Mean gap: {M_gap=:.3f}')

df_ = df.dropna(subset=['p_fragile_implied'])
df['p_fragile_only_w_implied'] = df_['p_fragile']

gap = df_['gap'].mean()
print(f'Mean gap only test statistics: {gap=:.3f}')
return df


def plot_subject_over_time(keys, bias_adjustment=.023):
  df = get_df_for_temporal_trends(bias_adjustment=bias_adjustment)

group_keys = ['General', 'Exp. & Cog.', 'Dev. & Edu.', 'Social',
              'Clinical', 'Applied']

pd.set_option('display.max_rows', 2000)
# for key in keys:
#     if key in ['gap', 'gap_drop']: continue
#     df_m = df.groupby('year')[key].mean()

if len(keys) == 2:
  fig, axs = plt.subplots(1, 2, figsize=(6.5, 3.7))
elif len(keys) == 3:
  fig, axs = plt.subplots(1, 3, figsize=(10.5, 3.7))
elif len(keys) == 6:
  fig, axs = plt.subplots(2, 3, figsize=(10.5, 6.3))
else:
  fig, axs = plt.subplots(2, 2, figsize=(6.5, 6.3))

for i, key in enumerate(keys):
  if len(keys) in [2, 3]:
  plt.sca(axs[i])
else:
  if len(keys) == 6:
  row = i // 3
col = i % 3
else:
  row = i // 2
col = i % 2
plt.sca(axs[row, col])
# df_ = df.dropna(subset=[key])
if key == 'p_fragile_implied_rel_sig':
  df_ = df[df['p_fragile_implied_rel_sig'] <= 1]
else:
  df_ = df

if key == 'gap':
  key = ('p_fragile', 'p_fragile_implied')
elif key == 'gap_drop':
  key = ('p_fragile_only_w_implied', 'p_fragile_implied')
plot_key(df_, key=key, ax=plt.gca(), group_keys=group_keys)

tuples_lohand_lolbl = [plt.gca().get_legend_handles_labels()]
tolohs = zip(*tuples_lohand_lolbl)
handles, labels = (sum(list_of_lists, []) for list_of_lists in tolohs)
leg = fig.legend(handles, labels, loc='lower center', ncol=6,
                 fontsize=12.5 if len(keys) == 6 else 11,
                 frameon=False, columnspacing=0.8, handletextpad=0.3,
                 markerscale=2, handlelength=1.5)
for line in leg.get_lines():
  line.set_linewidth(1.5)

if len(keys) in [2, 3]:
  plt.subplots_adjust(left=0.075, bottom=0.20, right=0.96,
                      top=0.85, wspace=0.35 if 'gap' in keys else 0.24,
  )
else:
  plt.subplots_adjust(left=0.075,
                      bottom=0.125 if len(keys) == 6 else 0.11,
                      right=0.96, top=0.915, wspace=0.24,
                      hspace=0.45 if len(keys) == 6 else (.4 if 'gap' in keys else 0.325)
  )
Path(r'../figs_and_tables').mkdir(parents=True, exist_ok=True)
if keys == ['p_fragile', 'p_fragile_implied', ]:
  plt.savefig('../figs_and_tables/Figure_2_temporal_p_frag.png', dpi=600)
elif keys == ['t_N_sig', 'd_sig']:
  plt.savefig('../figs_and_tables/Figure_4_temporal_sample_effect.png', dpi=600)
elif keys == ['gap', 'gap_drop']:
  plt.savefig('../figs_and_tables/Figure_S10_temporal_gap.png', dpi=600)
else:
  print(f'No file saved: {keys=}')
plt.show()


if __name__ == '__main__':
  KEYS = ['p_fragile', 'p_fragile_implied']  # Figure 2
plot_subject_over_time(KEYS)
KEYS = ['t_N_sig', 'd_sig']  # Figure 4
plot_subject_over_time(KEYS)
KEYS = ['gap', 'gap_drop']  # Figure S10
plot_subject_over_time(KEYS)
